<?php
$clave = 'Admin.Amexport*';
echo password_hash($clave, PASSWORD_DEFAULT);
