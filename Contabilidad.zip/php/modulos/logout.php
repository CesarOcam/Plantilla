<?php
session_start();
$_SESSION = [];
session_destroy();
header('Location: /portal_web/Contabilidad/login.php'); // o la página de login
exit;
